# Legal Document Form

## Section 1: Fill Out (Manual Input)

### Company Information
- Company Address: 
- Company Founded: 
- Business Type: 
- Industry: 

### Legal & Compliance
- Effective Date: 
- Last Updated: 
- Governing Law: 

### Privacy & Data
- Privacy Email: 
- Personal Information Collected: 
- Data Retention Period: 
- Data Request Process: 

### Customer Service
- Return Policy (days): 
- Return Shipping: 
- Returns Address: 
- Digital Refunds: 
- Support Hours: 
- Support Email: 

### Copyright & Content
- Copyright Agent: 
- Content Moderation: 

### Service & Business Model
- Service Description: 
- Product Types: 
- Business Model: 

---

## Section 2: Requires Confirmation

### Business Operations
- Amazon Associates: 
- Affiliate Programs: 
- Sponsored Content: 
- Product Types: 
- Service Description: 
- Subscription Services: 

### Terms of Service
- Service Type: 

---

## Section 3: Auto-Detected (No Action Needed)

### Company Information
- Website URL: 
- Company Name: 
- Contact Email: 
- Contact Phone: 

### Website & Technology
- User Accounts: 
- User Content: 
- Payment Processing: 
- E-commerce: 
- Google Analytics: 
- Advertising: 
- Social Media: 
- Cookies: 
- EU Users: 
- International Sales: 

### Social Media Profiles
- LinkedIn: 
- Twitter: 
- Facebook: 
- Instagram: 

### Document-Specific
- Data Collection Methods: 
- Third-Party Integrations: 
- Cookie Types: 
- Analytics Services: 
- Affiliate Links: 
- Payment Processors: 
- Content Upload Features: 
- Service Types: 

---

**Instructions:** 
- Section 1: Fill out manually (business decisions only)
- Section 2: Cursor detects from code, you confirm accuracy
- Section 3: Auto-detected (no action needed)
